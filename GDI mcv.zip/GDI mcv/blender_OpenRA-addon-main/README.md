# blender_OpenRA-addon
使用Blender轻松制作OpenRA的素材  
Easily create OpenRA assets with Blender  

## 如何使用：  
选择下载zip,然后进入Blender进行插件安装。  
需要配合zip中的模板场景使用。  

## Using：
Select Download Zip and then go to Blender for plug-in installation.  
You need to use the template scene in ZIP.  

This addon is still in development.  
这个插件还在开发中.